package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.training.model.Admin;
import com.training.model.Trainee;
import com.training.service.TraineeService;

@Controller
public class TraineeController {
	Trainee deleteTrainee;
	@Autowired
	TraineeService service;
	@RequestMapping("/")
	public ModelAndView showIndexPage()
	{
		ModelAndView mv= new ModelAndView("index");
		mv.addObject("admin",new Admin());
		return mv;	
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/home")
	public ModelAndView displayAllTraineeOperations(@ModelAttribute("admin") Admin admin)
	{				
		
		boolean checkAdmin=service.validateAdmin(admin);
		if(checkAdmin)
		{
			ModelAndView mv= new ModelAndView("home");
			String message = "Login Successful";
			mv.addObject("successMessage", message);
			return mv;
		}
		else
		{
			ModelAndView mv= new ModelAndView("index");
			String message = "Login Failed";
			mv.addObject("successMessage", message);
			return mv;
		}
	}
	
	 @RequestMapping(value="/addTrainee", method=RequestMethod.GET) 
	  public  ModelAndView loadAddTrainee() {
		 ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("addTrainee");
		  mav.addObject("trainee", new Trainee()); 
		  return mav; 
	  }
	 
	 @RequestMapping(value="/addTrainee", method=RequestMethod.POST)
		public ModelAndView addTraieePage(@ModelAttribute("trainee") Trainee trainee) {
			service.addTrainee(trainee);
			ModelAndView mav = new ModelAndView("addTrainee");
			return mav;
		}
	 
	 @RequestMapping(value="/deleteTraineePage")
		public ModelAndView getdeleteTraineePage()
		{
			ModelAndView mv=new ModelAndView("deleteTrainee");
			mv.addObject("trainee",new Trainee());
			return mv;
		}

		
		@RequestMapping(value="/getDeleteTraineeDetail")
		public ModelAndView getDeleteTraineeDetail(@ModelAttribute("trainee") Trainee trainee,Model model)
		{
			ModelAndView mv;
			System.out.println(trainee.getTraineeId());
			int tid = trainee.getTraineeId();
			trainee=service.getTrainee(tid);
			deleteTrainee = trainee;
			if(trainee.getTraineeName()!=null)
			{
				mv=new ModelAndView("deleteTrainee");
				mv.addObject("trainee1",trainee);
				return mv;
			}
			else
			{
				mv=new ModelAndView("deleteTrainee");
				return mv;			
			}
		}
		
		@RequestMapping(value="/deleteTrainee")
		public ModelAndView deleteTrainee(@ModelAttribute("trainee1") Trainee trainee1,Model model)
		{
			//System.out.println("getting trainee id to dleet" + deleteTrainee.getTraineeId());
			ModelAndView mv;
			//trainee1=service.deleteTrainee(deleteTrainee.getTraineeId());
			boolean	result=service.deleteTrainee(deleteTrainee.getTraineeId());

			if(result)
			{
				System.out.println("trainee deleted successfully");
				mv=new ModelAndView("home");
				//mv.addObject("trainee",trainee1);
				return mv;
			}
			else
			{
				mv=new ModelAndView("deleteTrainee");
				mv.addObject("trainee",new Trainee());
				return mv;
			}
		
		}

}
