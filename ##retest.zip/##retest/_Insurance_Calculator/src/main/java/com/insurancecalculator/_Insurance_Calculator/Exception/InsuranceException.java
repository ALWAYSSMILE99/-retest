package com.insurancecalculator._Insurance_Calculator.Exception;

public class InsuranceException extends RuntimeException{
	public InsuranceException()
	{
		super("Some Exception occur! Sorry for inconvinience");
	}
	public InsuranceException(String str)
	{
		super(str);
	}
}
