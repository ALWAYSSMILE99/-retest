package com.insurancecalculator._Insurance_Calculator.insurenceservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.insurancecalculator._Insurance_Calculator.entity.Insurance;
import com.insurancecalculator._Insurance_Calculator.insurencedao.IInsuranceDAO;
/*
 *Authorname:Ajay Mehta
 *mailid:ajay.a.mehta@capgemini.com
 *Version:1.0
 *Description:this class perform all service related function of this project means all information comming
 *from controller sending it to database layer
 */
@Service
@Transactional
public class InsuranceService implements IInsuranceService{

@Autowired
IInsuranceDAO insuranceDao;
/*
 * Method name:-deleteInsurance 
 * Method Description:-this method delete record from database based on id
 * 
 */
@Override
public Insurance deleteInsurance(int id) {
	return insuranceDao.deleteInsurance(id);
	
}
/*
 * Method name:-GetSingleInsurance 
 * Method Description:-this method fetch record from database based on given id on its parameter
 * 
 */
@Override
public Insurance GetSingleInsurance(int id) {
	 return insuranceDao.GetSingleInsurance(id);
}
/*
 * Method name:-AddInsurance 
 * Method Description:-this method add record to database based on given 'insurance' class object comming as a parameter
 * and it is generating Insurance amount based on purchase year and onRoad price and then adding to database
 * 
 */
@Override
public Insurance AddInsurance(Insurance insurance) {
	 return insuranceDao.AddInsurance(insurance);
}
/*
 * Method name:-UpdateInsurance 
 * Method Description:-this method updating record in the database 
 * 
 */
@Override
public Insurance UpdateInsurance(Insurance insurance) {

	 return insuranceDao.UpdateInsurance(insurance);
}
/*
 * Method name:-viewAllInsuranceDetails 
 * Method Description:-this method returning all the record in the database  
 * 
 */
@Override
public List<Insurance> viewAllInsuranceDetails(int year) {
	return  insuranceDao.viewAllInsuranceDetails(year);
}



}
