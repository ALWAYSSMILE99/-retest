package com.insurancecalculator._Insurance_Calculator.insurencedao;

import java.util.List;

import com.insurancecalculator._Insurance_Calculator.entity.Insurance;

public interface IInsuranceDAO {

	public Insurance deleteInsurance(int id);

	public Insurance GetSingleInsurance(int id);

	public Insurance AddInsurance(Insurance insurance);

	public Insurance UpdateInsurance(Insurance insurance);

	public List<Insurance> viewAllInsuranceDetails(int year);

}
