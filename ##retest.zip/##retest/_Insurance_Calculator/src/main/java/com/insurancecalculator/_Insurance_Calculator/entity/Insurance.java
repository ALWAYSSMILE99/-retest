package com.insurancecalculator._Insurance_Calculator.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
@Entity

public class Insurance {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
 private int id;
 private String vehicleModel;
 private double onRoadPrice;
 @Max(value=2019,message="year should not be grater than 2019")
 private int  purchaseYear;
 private double insuranceAmount;
 private Date expDate;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getVehicleModel() {
	return vehicleModel;
}
public void setVehicleModel(String vehicleModel) {
	this.vehicleModel = vehicleModel;
}
public double getOnRoadPrice() {
	return onRoadPrice;
}
public void setOnRoadPrice(double onRoadPrice) {
	this.onRoadPrice = onRoadPrice;
}
public int getPurchaseYear() {
	return purchaseYear;
}
public void setPurchaseYear(int purchaseYear) {
	this.purchaseYear = purchaseYear;
}
public double getInsuranceAmount() {
	return insuranceAmount;
}
public void setInsuranceAmount(double insuranceAmount) {
	this.insuranceAmount = insuranceAmount;
}
public Date getExpDate() {
	return expDate;
}
public void setExpDate(Date expDate) {
	this.expDate = expDate;
}
@Override
public String toString() {
	return "Insurance [id=" + id + ", vehicleModel=" + vehicleModel + ", onRoadPrice=" + onRoadPrice + ", purchaseYear="
			+ purchaseYear + ", insuranceAmount=" + insuranceAmount + ", expDate=" + expDate + "]";
}
 

}
