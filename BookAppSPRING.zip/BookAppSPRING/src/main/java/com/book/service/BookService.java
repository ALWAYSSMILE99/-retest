package com.book.service;

import java.util.List;

import com.book.bean.Book;
import com.book.exception.BookException;

public interface BookService {

	public List<Book> addBook(Book b) throws BookException;
	public Book getBookById(int id) throws BookException;
	public void deleteBook (int id) throws BookException;
	public List<Book> getAllBooks() throws BookException;
	public List<Book> getBookByAuthor(String author) throws BookException;
	public List<Book> updateBook(int id, Book b) throws BookException;
	
	
}
